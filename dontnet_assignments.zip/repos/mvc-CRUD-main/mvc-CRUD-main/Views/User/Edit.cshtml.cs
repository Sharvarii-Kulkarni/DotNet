using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace demo.Views.User
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
