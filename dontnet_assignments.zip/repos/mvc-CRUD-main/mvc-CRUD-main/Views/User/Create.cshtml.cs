using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace demo.Views.User
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
