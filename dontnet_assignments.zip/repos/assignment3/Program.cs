﻿class Program
{
    static void Main()
    {
        EmployeeManagement.RunEmployeeSystem(); // Calls the function from EmployeeManagement.cs
    }
}
