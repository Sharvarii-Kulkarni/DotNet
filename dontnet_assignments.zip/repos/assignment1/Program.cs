﻿class Program
{
    static void Main()
    {
        //StringManipulator.RunStringManipulation(); // Calls the function from StringManipulator.cs

        // CalculatorApp.RunCalculator();  // Example: Calls the function from CalculatorApp.cs

        //DigitSumCalculator.RunDigitSumCalculator(); // Calls the function from DigitSumCalculator.cs

        //PalindromeChecker.RunPalindromeChecker();

        SquareRootCalculator.RunSquareRootCalculator();
    }
}
